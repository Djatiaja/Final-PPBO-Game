package Gamestate;

import java.awt.event.MouseEvent;

import Main.Game;
import ui.MenuButton;

public enum GameState {
    PlAYING, MENU, QUIT;
    public static GameState state = MENU;


}




